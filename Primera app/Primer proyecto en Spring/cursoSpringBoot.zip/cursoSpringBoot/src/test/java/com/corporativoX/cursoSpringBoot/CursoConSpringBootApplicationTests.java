package com.corporativoX.cursoSpringBoot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CursoConSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
