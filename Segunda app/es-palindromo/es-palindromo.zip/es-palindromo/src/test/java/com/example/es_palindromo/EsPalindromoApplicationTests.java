package com.example.es_palindromo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EsPalindromoApplicationTests {

	@Test
	void contextLoads() {
	}

}
